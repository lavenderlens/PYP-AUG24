import re


address_list = []

while True:
    email = input("Please enter email address: ")
    email_pattern = "\w+@\w+.\w+.\w+"
    match = re.match(email_pattern, email)

    if match: 
        print(f"Email address {email} is valid")
        address_list.append(email)
    else:
        print(f"Email address {email} is invalid")    
    if email == "0":
        break

print(address_list)





