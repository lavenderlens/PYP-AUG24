unique_nums_1 = {44,55,66,44,55,66}
print(unique_nums_1)

unique_nums_2 = set((44,55,66,44,55,66))
unique_nums_2 = set({44,55,66,44,55,66})
unique_nums_2 = set([44,55,66,44,55,66])

print(unique_nums_2)

unique_nums_list = list(unique_nums_2)
print(unique_nums_list)


unique_nums_3 = {55,66,33,22,11}
print(common_values := unique_nums_1.intersection(unique_nums_3))
print(common_values := unique_nums_1.difference(unique_nums_3))
print(common_values := unique_nums_1.symmetric_difference(unique_nums_3))
#print(common_values := unique_nums_1.symmetric_difference_update(unique_nums_3))
print(unique_nums_1, unique_nums_3)
















