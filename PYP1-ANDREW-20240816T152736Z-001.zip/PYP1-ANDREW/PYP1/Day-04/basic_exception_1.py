
try:
    num1 = float(input("Enter first number:"))
    num2 = float(input("Enter second number:"))
    total = num1 + num2
    print(f"sum of {num1} and {num2} is {total}")
except:
    print("Something went wrong...")



