import json

books = [
    {'title': 'The Gruffalo', 'author': 'Julia Donaldson'},
    {'title': 'The Twits', 'author': 'Roald Dahl'},
    {'title': 'he Bippolo Seed', 'author': 'Dr. Seuss'}
]

books_json = json.dumps(books)
print(books_json)

books_python = json.loads(books_json)
print(books_python)

with open("widget.json") as widget_file:
    a_dict = json.load(widget_file)
    print(widget_file)

    a_dict["widget"]["image"]["src"] = "TEST"
    a_dict["widget"]["image"]["name"] = "TEST"
    a_dict["widget"]["text"]["onMouseUp"] = "TEST"

with open("modify-widget.json", mode="w") as modify_widget_file:
    json.dump(a_dict, modify_widget_file)

    









