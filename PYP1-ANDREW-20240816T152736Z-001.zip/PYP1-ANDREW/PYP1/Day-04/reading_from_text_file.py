file = open("data.txt")
#print(type(file))
#print(dir(file))

#content = file.read()
#print(content)
#file.close()

#content = file.read(10)
#print(content)



line = file.readline()
print(line)






