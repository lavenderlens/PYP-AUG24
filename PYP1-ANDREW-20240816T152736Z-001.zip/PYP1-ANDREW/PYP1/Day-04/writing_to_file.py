file = open("data.txt", mode="a")

text = "\nadditional content\n"
file.write(text)


file.writelines(text)

file.close()









