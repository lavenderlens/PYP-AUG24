try:
    num1 = float(input("Enter first number:"))
    num2 = float(input("Enter second number:"))
    total = num1 / num2
   
except ValueError:
    print("Enter numbers only")
except ZeroDivisionError:
    print("Cannot dvide by zero")
except:
    print("Unknown Error")
else: 
     print(f"{num1} divided by {num2} is {total}")
finally:
    print("Thanks")
     







