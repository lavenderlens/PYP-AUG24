import BookError

books = []

num_books = 0

def add_new_book(title, author_first, author_last):
    if len(author_first.strip()) <2 or len(author_last.strip()) < 2:
        #print("More than two chars")
        raise BookError("Author names must be more than two chars long")
    else:    
        book = {"title":title, "author first name":author_first, "author last name":author_last}
        books.append(book)
        global num_books
        num_books += 1
try:
    add_new_book("Book 1", "Andy", "Tang")
    add_new_book("Book 2", "John", "Smith")
    add_new_book("B", "J", "Chan")
except:
    print("At least one book not added")

print(books)











