s1 = "Hello"
s2 = "Hello"

print(s1, id(s1))
print(s2, id(s2))

print(s1 == s2)



list1 = ["Hello"]
list2 = ["Hello"]

print(list1, id(list1))
print(list1, id(list2))

print(list1 == list2)


import math

print(math.pi)
print(f"PI to 4 decimal places: {math.pi:.4f}")

price = 19.99
print(f"price: {price:.0f}")







