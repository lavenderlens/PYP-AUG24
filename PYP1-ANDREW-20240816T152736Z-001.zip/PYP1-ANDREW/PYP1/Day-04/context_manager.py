with open("data.txt") as file:
    for line in file: 
        print(f"a line{line}")




        