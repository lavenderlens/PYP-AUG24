book = {}
book = dict()

book["title"] = "Scary Smart"
book["author"] = "Billy Bob"
book["published"] = 2024

print(book)
print(book["title"])
print(book.get("author"))

#print(pub_year := book.pop("published"))
#print(book)


for key in book: 
    print(key)

for value in book.values(): 
    print(value)

for key, value in book.items(): 
    print(key, value)


for key in book:
    print(f"{key}: {book[key]}")    

book2 = book

book2["published"] = 2020
print(book2)
print(book)


book3 = book.copy()
book3["published"] = 2021
print(book3)

book["ratings"] = [4,4,3.5,5]
print(book)

book4 = book.copy()
book4["ratings"].append(1)
print(book)

import copy

book5 = copy.deepcopy(book)
book5["ratings"].append(0)
print(book)












