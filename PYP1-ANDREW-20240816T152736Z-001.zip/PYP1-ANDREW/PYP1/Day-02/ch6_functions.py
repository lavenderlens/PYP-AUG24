def get_greet1():
    return "Hello!"

def get_greet2(name):
    return "Hello " + name

def get_product(num1, num2):
    return num1 * num2

def get_first(list):
    return list[0]

def get_name(dict):
    return dict["name"]

def get_circumference(radius):
    return int(2 *3.14 * radius)



    