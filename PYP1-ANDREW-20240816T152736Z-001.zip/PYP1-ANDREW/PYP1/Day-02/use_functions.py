#import functions #pulls all functions

#print(functions.add(1,2))



from functions import add 

print(add(5,6))
