import random

magic_number = random.randint(1, 10)
print(magic_number)

user_guess = int(input("Please choose a number between 1-10, you get 3 guesses: "))

counter = 0
while user_guess != magic_number:
    print("Wrong number, guess again")
    counter += 1
    if counter < 3 and user_guess < magic_number:
        user_guess = int(input("Too low. Please enter another number: "))
    elif counter < 3 and user_guess > magic_number:
        user_guess = int(input("Too high. Please enter another number: "))
    else:
        print("Too many attempts, you lose!!")
        break
else:
    print("Winner winner chicken dinner!!")



