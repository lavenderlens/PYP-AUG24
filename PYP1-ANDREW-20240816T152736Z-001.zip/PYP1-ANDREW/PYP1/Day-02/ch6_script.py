from ch6_functions import get_greet1, get_greet2, get_product, get_first, get_name, get_circumference

print(get_greet1())

print(get_greet2("Andy"))

print(get_product(2,5))

nums = [1,2,3]
print(get_first(nums))

print(get_circumference(10))





