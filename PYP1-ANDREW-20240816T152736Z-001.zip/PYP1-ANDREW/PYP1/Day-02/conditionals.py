#if True:
   # print("True")

#if False:
 #   print("False") #Does not print anything


if True:
    print("True")
else:
    print("Else")   


if False:
    print("True")
elif True:
    print("False")
else:
    print("Else")   




