names = ['Michael Jackson', 'David Bowie', 'Janet Jackson', 'James Brown',\
         'Gordon Brown', 'David Hume', 'Michael Jackson']

print("\nas LIST:")
for name in names:
    print (name)

print (len(names))

print("\nas Lsliced IST:")
for name in names[2:4]:
    print (name)

print("\nas sliced LIST:")
for name in names[::-1]: #reverse list order
    print (name)    


names_set = {'Michael Jackson', 'David Bowie', 'Janet Jackson', 'James Brown',\
         'Gordon Brown', 'David Hume', 'Michael Jackson'}


print("\nas LIST:")
for name in names_set:
    print (name)


coords = {"x": 3, "y":5, "z": 6}

for key in coords.keys():
    print(key)

for value in coords.values():
    print(value)



for key, value in coords.items():
    print(key, value)



word = "opposition"
for character in word:
    print(character)


for i in range(1,10):
    print(i+1)



for i in range(5,51, 5): #print 5-50 in steps of 5
    print(i)



for name in names:
    print(name)
    if name == "James Brown":
        print(f"ERROR ={name} to funky for my code")
        break
else:
    print("list processed with no errors")


counter = 0
while counter < len(names):
    print(names[counter])
    counter += 1


counter = 0
while counter < len(names):
    print(names[counter])
    if  names[counter] == "James Brown":
        counter += 1
        continue
    counter += 1
else:
    print("loop completed")



list_of_names = []
while True:
    name = input("Enter a name or X to quit")
    if name.lower() == "x":
        break
    list_of_names.append(name)











