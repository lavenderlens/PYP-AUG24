def add(num1, num2):
    return num1 + num2

result = add (1,2)
print(result)
print(add(3,4))


my_var = "hello"

def first_char_of_word():
    print(my_var[0])

first_char_of_word()


def open_account(name, balance):
    balance += 100
    return (name, balance)

acc01 = open_account("AT Offshore)", 2500)
print(acc01)

#acc02 = open_account(3500, "AT Offshore)") #wrong order compared to function defined as positional
#print(acc02)

def open_acc2(name="customer", balance=0):
    balance += 100
    return (name, balance)

acc3 = open_acc2()
print(acc3)


acc4 = open_acc2(name="AT", balance = 300) #named so order does not matter
print(acc4)



def greet1():
    print("Hello")
    print("from greet 1")

    greet1()
    result_greet1 = greet1()
    print(result_greet1)

def greet2():
    return "Hello" + "\n" + "from greet2" + "\n" + "how are you today?"

greet2()
print(greet2())




