num1 = 1
print(type(num1))

my_list = ["bat", "ball", "gloves"]
print(type(my_list))
print(my_list[1])

my_tuple = (42, "The ultimate answer")
print(type(my_tuple)
      )


