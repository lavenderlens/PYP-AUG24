your_name = input("Enter your name")
print("You entered", your_name)
