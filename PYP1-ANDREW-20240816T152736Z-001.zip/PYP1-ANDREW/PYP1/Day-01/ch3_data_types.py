traveller_id = 1234
print(type(traveller_id))

first_name = "John"
print(type(first_name))

last_name = "Doe"
print(type(last_name))

checked_bags = 0
print(type(checked_bags))
print(bool(checked_bags))

visited_countries = {"Latvia", "Guyana", "Yemen", "Uzbekistan"}
print(type(visited_countries))

flight = "LGW to CDG"
print(type(flight))

flight_time = "1 hour 15 minutes"
print(type(flight_time))



