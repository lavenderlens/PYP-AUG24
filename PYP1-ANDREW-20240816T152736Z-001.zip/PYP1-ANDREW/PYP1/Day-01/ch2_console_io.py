name = input("Enter your name: ")
age = input("Enter your age: ")
print("Your name is", name, "and you are", age, "years old")
