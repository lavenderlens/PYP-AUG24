my_list = (1,2,3)
#print(1 in my_list)
#print(4 in my_list)
#print(1 not in my_list)


print(bool(0) and bool(1))
print(bool(0) or bool(1))
print(not (bool(0) or bool(1)))

