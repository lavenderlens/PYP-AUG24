print("Hello World") # double or single qoutes OK
