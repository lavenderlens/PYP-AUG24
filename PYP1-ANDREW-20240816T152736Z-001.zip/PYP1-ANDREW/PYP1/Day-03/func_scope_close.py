next_num = 1

def get_next_num():
    return next_num

print(get_next_num())

def inc_next_num():
    #next_num +=1
    return next_num

#print(inc_next_num())


def inc_next_num_local():
    next_num = 1
    next_num +=1
    return next_num

print(inc_next_num_local())


def inc_next_num_global():
    global next_num
    next_num +=1
    return next_num

print(inc_next_num_global())


def inc_with_closure():
    next_num = 100
    def get_next_num():
        print(next_num)
    get_next_num()

inc_with_closure()



def inc_with_closure():
    next_num = 100
    def get_next_num():
        #next_num += 1 this won't work as not initialised
        return next_num
    get_next_num()

inc_with_closure()
   


def inc_with_closure():
    next_num = 100
    def get_next_num():
        nonlocal next_num
        next_num += 1
        return next_num
    return get_next_num

#print(inc_with_closure())

my_closure = inc_with_closure()

print(my_closure())
print(my_closure())
print(my_closure())
print(my_closure())


my_closure2 = inc_with_closure()

print(my_closure2())
print(my_closure2())
print(my_closure2())
print(my_closure2())





   


