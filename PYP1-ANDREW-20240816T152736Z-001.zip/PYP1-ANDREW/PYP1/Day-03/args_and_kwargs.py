def greet(name, hobbies):
    print(f"Hello my name is {name}")
    print(f"My hobbies are {hobbies}")

greet("Andy", "Photography, music, food")
greet("Andy", ["Photography", "music", "food"])


def greet_with_args(name, *hobbies):
    print(f"Hello my name is {name}")
    print(f"My hoobies are {hobbies}")

greet_with_args("Billy")
greet_with_args("Billy", "walking", "cycling")



def greet_with_kwargs(name, *hobbies, **other_details):
    print(f"Hello my name is {name}")
    print(f"My hobbies are {hobbies}")
    print(f"I also have other details {other_details}")

greet_with_kwargs("Billy")
greet_with_kwargs("Andy", "music", "photography", county="warks", country="England")







