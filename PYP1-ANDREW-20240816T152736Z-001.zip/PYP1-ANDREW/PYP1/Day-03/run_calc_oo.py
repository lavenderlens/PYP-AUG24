from calc_oo import Calculator

calc = Calculator()

calc.add(5)
calc.mul(3)
calc.sub(1)
calc.div(2)

result = calc.equals()

print(result)