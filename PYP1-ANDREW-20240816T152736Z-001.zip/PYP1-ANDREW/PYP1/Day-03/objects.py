class Client:
    def __init__(self):
        self.name = "Client"
        self.email= "no email supplied"
        self.depenents = []
    def __str__(self):
        return f"Name: {self.name}, email: {self.email}, dependents: {self.depenents}"
    
client1 = Client()

print(client1)

print(client1.name)


class ClientWithParams:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.depenents = []


    def add_depenedent(self, name):
        #name = input("Enter dependent name:")
        self.depenents.append(name)
        print(f"{name} added as dependent. No. of dependents is now {len(self.depenents)}")


    def __str__(self):
        return f"Name: {self.name}, email: {self.email}, dependents: {self.depenents}"
    

#clientWithParams = ClientWithParams() doesn't work as no data supplied

clientWithParams = ClientWithParams("Andy", "andy@andy.com")

print(clientWithParams)

clientWithParams.add_depenedent("Bob1")
clientWithParams.add_depenedent("Bob2")
clientWithParams.add_depenedent("Bob3")

print(clientWithParams)




