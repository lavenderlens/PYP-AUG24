import calculator_proc

calculator_proc.add(5)
calculator_proc.mul(3)
calculator_proc.sub(1)
calculator_proc.div(2)

result = calculator_proc.equals()

print(result)
print(calculator_proc.total)



