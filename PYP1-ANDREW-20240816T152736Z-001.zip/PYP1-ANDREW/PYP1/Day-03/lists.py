nums = []
nums = list()
nums = [1,2,3]

print(nums[2])

nums[2] = 4

nums.append(5)

print(nums)


fib = [0,1,1,2,3,5,8,13,21,34]
print(len(fib))


print(slice1 := fib[::1])

print(f"min elements: {min(fib)}")
print(f"max elements: {eve(fib)}")

list5 = fib + [55,89,144]
print(list5)
print(list6 := list5 *10)


scaled_list = [el* 2 for el in fib]
print(scaled_list)

list_of_under_10s = [el for el in fib if el <= 10]
print(list_of_under_10s)







