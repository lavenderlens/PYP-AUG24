my_tuple = ("Andy", 45, ["Photography", "music"], True)
my_empt_tuple = ()
my_empt_tuple = tuple()

fib = (0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144)

print(fib.count(1))
print(fib.index(144))


print(low_num := fib[0:6])


for el in fib:
    print(el)

for index, el in enumerate(fib):
    print(index, el)


print(fib + (233,377))

print(fib * 2)












