from ch6_profile_matcher import build_profile

p_age=int(input("Please enter your age: "))

build_profile(p_age)

