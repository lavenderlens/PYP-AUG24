class TrainingCourse:
    def __init__(self, title, duration, price):
        self.title = title
        self.duration = duration
        self.price = price
        self.delegate = []

    def add_delegate(self, name):
        self.delegate.append(name)
        
    def get_cost(self):
        revenue = self.price * len(self.delegate)
        return revenue
    
    def __str__(self):
        return f"Course Title: {self.title}, Duration (Days): {self.duration}, Delegates: {self.delegate}"
    
course = TrainingCourse("PYP1", 4, 1600)

course.add_delegate("Bob1")
course.add_delegate("Bob2")
course.add_delegate("Bob3")

print(course)
print(f"Total cost of course: £{course.get_cost()}")




