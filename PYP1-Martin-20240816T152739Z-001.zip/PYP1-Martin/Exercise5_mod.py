def build_profile():
    profile = {
        "age": 0,
        "hobbies": se()
    }
    profile["age"] = int(input("Enter age of client: "))
    more_hobbies = True
    while more_hobbies:
        profile["hobbies"].append(input("Enter hobbie:"))
        more = 

    
    

