print("Hello World") # 
# double or single quotes ok in Python
# script mode
