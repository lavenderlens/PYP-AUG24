from ex4_module import greet1, greet2, get_product, get_first, get_name, get_circumference

print(greet1())

print(greet2("Martin"))

print(get_product(3,4))

nums = [1,2,3]
print(get_first(nums))

print(get_name({"name": "Simo"}))

print(get_circumference(10))

