my_str = "hello"
first_character = my_str[0]
print(first_character)
print(len(my_str)) #length
print(my_str.upper())
my_list = ["bat", "ball", "gloves"]
print(my_list)
my_tuple = ("bat", "ball", "gloves")
print (my_tuple)
