birth_year = input("Enter birth year: ")
birth_year = int(birth_year)
if birth_year > 1995:
    print("Gen Z")
elif birth_year > 1976:
    print("Mill")
elif birth_year > 1965:
    print("Mill")
elif birth_year > 1945:
    print("Baby Boomer")

