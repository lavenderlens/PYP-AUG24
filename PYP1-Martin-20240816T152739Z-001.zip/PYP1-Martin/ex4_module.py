def greet1():
    return "G-day!"

def greet2(name):
    return "G-Day " + name

def get_product(num1, num2):
    return num1 + num2

def get_first(a_list):
    return a_list[0]

def get_name(a_dict):
    return a_dict["name"]

def get_circumference(radius):
    return 2 * 3.14 * radius