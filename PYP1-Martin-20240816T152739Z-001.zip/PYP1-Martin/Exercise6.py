class TrainingCourse:
    def __init__(self, title, duration, ppp):
        self.title = title
        self.duration = duration
        self.ppp = ppp
        self.deligates = []

    def add_deligates(self, deligate_name):
        self.deligates.append(deligate_name)
        
    def total_rev(self):
        rev = self.ppp * len(self.deligates)
        return rev
    
python1 = TrainingCourse("Python Training Course 1", 4, 1600)
python1.add_deligates("Paul")
python1.add_deligates("Bill")
python1.add_deligates("Bob")

print(python1.title)
print(f"Duration {python1.duration}")
print(f"Price per candidate {python1.ppp}")
print(f"Total rev {python1.total_rev()}")