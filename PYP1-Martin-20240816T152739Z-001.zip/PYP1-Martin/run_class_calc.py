from class_calc import Calculator

calculator = Calculator()

calculator.add(5)