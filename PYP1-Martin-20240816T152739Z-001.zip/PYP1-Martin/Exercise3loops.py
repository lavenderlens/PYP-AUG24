import random
magic_number = random.randint(1, 10)

my_try = 1
while my_try <= 3:
    my_guess = int(input("guess number  between 1 and 10: "))
    if my_guess == magic_number:
        print("You Win")
        break
    elif my_guess > magic_number:
        print("too high")
    elif my_guess < magic_number:
        print("too low")
    my_try += 1


    






